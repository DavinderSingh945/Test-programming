module com.example.part {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.almasb.fxgl.all;

    opens com.example.part to javafx.fxml;
    exports com.example.part;
}
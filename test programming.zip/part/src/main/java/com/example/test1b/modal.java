package com.example.test1b;

public class modal {
    private String username;
    private String password;
    private int failedAttempts;
    private boolean isLocked;

    public modal(String username, String password) {
        this.username = username;
        this.password = password;
        this.failedAttempts = 0;
        this.isLocked = false;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public int getFailedAttempts() {
        return failedAttempts;
    }

    public void incrementFailedAttempts() {
        this.failedAttempts++;
    }

    public void resetFailedAttempts() {
        this.failedAttempts = 0;
    }

    public boolean isLocked() {
        return isLocked;
    }

    public void lockAccount() {
        this.isLocked=true;
    }
}

